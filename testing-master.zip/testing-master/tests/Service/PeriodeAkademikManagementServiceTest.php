<?php

namespace Tests\Service;

use App\Services\PeriodeAkademikManagementService;

class PeriodeAkademikManagementServiceTest extends ServiceTestCase
{
    public function test_index_periode()
    {
        //
    }

    public function test_show_periode()
    {
        //
    }

    public function test_show_periode_throw_model_not_found_exception()
    {
        //
    }

    public function test_store_periode()
    {
        //
    }

    public function test_update_periode()
    {
        //
    }

    public function test_update_periode_throw_model_not_found_exception()
    {
        //
    }

    public function test_destroy_periode()
    {
        //
    }

    public function test_destroy_periode_throw_model_not_found_exception()
    {
        //
    }

    /**
     * Setup the test environment.
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();

        $this->service = new PeriodeAkademikManagementService;
    }
}
