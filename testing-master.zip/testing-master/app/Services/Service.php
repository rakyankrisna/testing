<?php

namespace App\Services;

abstract class Service
{
    // dibuat abstract agar tidak bisa dibuat object-nya (harus di-extends)
}
