<?php

namespace Tests\Service;

class KRSValidationServiceTest extends ServiceTestCase
{
    public function test_constructor_throw_mahasiswa_not_found_exception()
    {
        //
    }

    public function test_constructor_throw_periode_not_found_exception()
    {
        //
    }

    public function test_constructor_throw_perwalian_not_found_exception()
    {
        //
    }

    public function test_validasi_krs()
    {
        //
    }

    public function test_validasi_krs_throw_krs_masih_kosong_exception()
    {
        //
    }

    public function test_validasi_krs_throw_krs_sudah_valid_exception()
    {
        //
    }

    public function test_batalkan_validasi_krs()
    {
        //
    }

    public function test_batalkan_validasi_krs_throw_krs_belum_valid_exception()
    {
        //
    }

    public function test_batalkan_validasi_krs_throw_krs_sudah_dinilai_exception()
    {
        //
    }
}
