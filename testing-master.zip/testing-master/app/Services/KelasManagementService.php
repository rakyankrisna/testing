<?php

namespace App\Services;

class KelasManagementService extends Service
{
    public function indexKelas()
    {
        //
    }

    public function showKelas(int $idKelas)
    {
        //
    }

    public function storeKelas(array $data)
    {
        //
    }

    public function updateKelas(int $idKelas, array $data)
    {
        //
    }

    public function destroyKelas(int $idKelas)
    {
        //
    }
}
