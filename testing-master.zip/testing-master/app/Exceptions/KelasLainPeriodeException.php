<?php

namespace App\Exceptions;

use Exception;

class KelasLainPeriodeException extends Exception
{
    //
}
