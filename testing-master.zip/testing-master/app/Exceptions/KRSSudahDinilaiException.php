<?php

namespace App\Exceptions;

use Exception;

class KRSSudahDinilaiException extends Exception
{
    //
}
