<?php

namespace App\Models;

class UnitKerja extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'ms_unit_kerja';
}
