<?php

namespace App\Exceptions;

use Exception;

class KRSSudahValidException extends Exception
{
    //
}
