<?php

namespace App\Exceptions;

use Exception;

class KRSBelumValidException extends Exception
{
    //
}
