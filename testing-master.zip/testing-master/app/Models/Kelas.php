<?php

namespace App\Models;

class Kelas extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'ak_kelas';
}
