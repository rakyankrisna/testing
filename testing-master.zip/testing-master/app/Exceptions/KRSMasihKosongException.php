<?php

namespace App\Exceptions;

use Exception;

class KRSMasihKosongException extends Exception
{
    //
}
