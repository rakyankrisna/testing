<?php

namespace Tests\Service;

class KRSPlanningServiceTest extends ServiceTestCase
{
    public function test_constructor_throw_mahasiswa_not_found_exception()
    {
        //
    }

    public function test_constructor_throw_periode_not_found_exception()
    {
        //
    }

    public function test_constructor_throw_perwalian_not_found_exception()
    {
        //
    }

    public function test_constructor_throw_krs_sudah_valid_exception()
    {
        //
    }

    public function test_tambah_krs()
    {
        //
    }

    public function test_tambah_krs_throw_kelas_not_found_exception()
    {
        //
    }

    public function test_tambah_krs_throw_kelas_lain_periode_exception()
    {
        //
    }

    public function test_tambah_krs_throw_kelas_lain_unit_exception()
    {
        //
    }

    public function test_tambah_krs_throw_krs_bentrok_exception()
    {
        //
    }

    public function test_tambah_krs_throw_kelas_sudah_penuh_exception()
    {
        //
    }

    public function test_tambah_krs_throw_krs_melebihi_sks_exception()
    {
        //
    }

    public function test_hapus_krs()
    {
        //
    }

    public function test_hapus_krs_throw_kelas_not_found_exception()
    {
        //
    }

    public function test_hapus_krs_throw_krs_not_found_exception()
    {
        //
    }
}
