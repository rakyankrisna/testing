<?php

namespace Tests\Model;

use App\Models\Mahasiswa;

class MahasiswaModelTest extends ModelTestCase
{
    protected $model = Mahasiswa::class;
}
