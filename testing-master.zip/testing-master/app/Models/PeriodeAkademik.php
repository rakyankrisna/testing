<?php

namespace App\Models;

class PeriodeAkademik extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'ms_periode_akademik';
}
