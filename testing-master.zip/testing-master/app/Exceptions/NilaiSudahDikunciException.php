<?php

namespace App\Exceptions;

use Exception;

class NilaiSudahDikunciException extends Exception
{
    //
}
