<?php

namespace App\Services;

class PeriodeAkademikManagementService extends Service
{
    public function indexPeriode()
    {
        //
    }

    public function showPeriode(int $idPeriode)
    {
        //
    }

    public function storePeriode(array $data)
    {
        //
    }

    public function updatePeriode(int $idPeriode, array $data)
    {
        //
    }

    public function destroyPeriode(int $idPeriode)
    {
        //
    }
}
