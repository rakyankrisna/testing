<?php

namespace App\Services;

class KelasGradingService extends Service
{
    private $kelas;

    public function masukkanNilai(int $idKRS, float $nilaiNumerik)
    {
        //
    }

    public function kunciNilai()
    {
        //
    }

    public function batalkanKunciNilai()
    {
        //
    }
}
