<?php

namespace Tests\Service;

class KelasGradingServiceTest extends ServiceTestCase
{
    public function test_constructor_throw_kelas_not_found_exception()
    {
        //
    }

    public function test_masukkan_nilai()
    {
        //
    }

    public function test_masukkan_nilai_throw_krs_not_found_exception()
    {
        //
    }

    public function test_masukkan_nilai_throw_krs_lain_kelas_exception()
    {
        //
    }

    public function test_masukkan_nilai_throw_krs_belum_valid_exception()
    {
        //
    }

    public function test_masukkan_nilai_throw_nilai_sudah_dikunci_exception()
    {
        //
    }

    public function test_kunci_nilai()
    {
        //
    }

    public function test_kunci_nilai_throw_nilai_belum_lengkap_exception()
    {
        //
    }

    public function test_kunci_nilai_throw_nilai_sudah_dikunci_exception()
    {
        //
    }

    public function test_batalkan_kunci_nilai()
    {
        //
    }

    public function test_batalkan_kunci_nilai_throw_nilai_belum_dikunci_exception()
    {
        //
    }
}
