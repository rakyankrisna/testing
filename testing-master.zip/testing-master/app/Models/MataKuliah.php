<?php

namespace App\Models;

class MataKuliah extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'ak_mata_kuliah';
}
