<?php

namespace App\Exceptions;

use Exception;

class NilaiBelumLengkapException extends Exception
{
    //
}
