<?php

namespace App\Services;

class KRSValidationService extends Service
{
    private $perwalian;

    public function validasiKRS()
    {
        //
    }

    public function batalkanValidasiKRS()
    {
        //
    }
}
