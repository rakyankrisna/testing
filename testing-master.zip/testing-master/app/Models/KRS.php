<?php

namespace App\Models;

class KRS extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'ak_krs';
}
