<?php

namespace App\Services;

class MataKuliahManagementService extends Service
{
    public function indexMataKuliah()
    {
        //
    }

    public function showMataKuliah(int $idMataKuliah)
    {
        //
    }

    public function storeMataKuliah(array $data)
    {
        //
    }

    public function updateMataKuliah(int $idMataKuliah, array $data)
    {
        //
    }

    public function destroyMataKuliah(int $idMataKuliah)
    {
        //
    }
}
