<?php

namespace App\Services;

class UnitKerjaManagementService extends Service
{
    public function indexUnit()
    {
        //
    }

    public function showUnit(int $idUnit)
    {
        //
    }

    public function storeUnit(array $data)
    {
        //
    }

    public function updateUnit(int $idUnit, array $data)
    {
        //
    }

    public function destroyUnit(int $idUnit)
    {
        //
    }
}
