<?php

namespace App\Exceptions;

use Exception;

class KelasLainUnitException extends Exception
{
    //
}
