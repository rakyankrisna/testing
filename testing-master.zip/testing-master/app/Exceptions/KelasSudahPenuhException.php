<?php

namespace App\Exceptions;

use Exception;

class KelasSudahPenuhException extends Exception
{
    //
}
