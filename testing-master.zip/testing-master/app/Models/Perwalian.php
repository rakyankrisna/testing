<?php

namespace App\Models;

class Perwalian extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'ak_perwalian';
}
