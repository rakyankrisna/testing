<?php

namespace Tests\Model;

use App\Models\UnitKerja;

class UnitKerjaModelTest extends ModelTestCase
{
    protected $model = UnitKerja::class;
}
