<?php

namespace App\Exceptions;

use Exception;

class KRSLainKelasException extends Exception
{
    //
}
