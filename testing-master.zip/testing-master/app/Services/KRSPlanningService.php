<?php

namespace App\Services;

class KRSPlanningService extends Service
{
    private $mahasiswa;
    private $periode;
    private $perwalian;

    public function tambahKRS(int $idKelas)
    {
        //
    }

    public function hapusKRS(int $idKelas)
    {
        //
    }
}
