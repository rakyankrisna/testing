<?php

namespace App\Services;

class MahasiswaManagementService extends Service
{
    public function indexMahasiswa()
    {
        //
    }

    public function showMahasiswa(int $idMahasiswa)
    {
        //
    }

    public function storeMahasiswa(array $data)
    {
        //
    }

    public function updateMahasiswa(int $idMahasiswa, array $data)
    {
        //
    }

    public function destroyMahasiswa(int $idMahasiswa)
    {
        //
    }
}
