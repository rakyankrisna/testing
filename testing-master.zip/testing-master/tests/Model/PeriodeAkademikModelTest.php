<?php

namespace Tests\Model;

use App\Models\PeriodeAkademik;

class PeriodeAkademikModelTest extends ModelTestCase
{
    protected $model = PeriodeAkademik::class;
}
