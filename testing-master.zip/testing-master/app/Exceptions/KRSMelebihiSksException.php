<?php

namespace App\Exceptions;

use Exception;

class KRSMelebihiSksException extends Exception
{
    //
}
