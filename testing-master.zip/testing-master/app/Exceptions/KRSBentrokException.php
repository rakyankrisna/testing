<?php

namespace App\Exceptions;

use Exception;

class KRSBentrokException extends Exception
{
    //
}
